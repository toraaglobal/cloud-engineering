#!/bin/bash
#set variables names
apiBucket=$(aws s3api list-buckets --output text --query 'Buckets[?contains(Name, `apibucket`) == `true`] | [0].Name')
notesTable='Notes'


echo $apiBucket

notesTable='Notes'

echo $notesTable

# add two required lambda variables 
aws lambda update-function-configuration \
--function-name dictate-function \
--environment Variables="{MP3_BUCKET_NAME=$apiBucket, TABLE_NAME=$notesTable}"


# publish AWS lambda function
cd ~/environment/api/dictate-function

# zip the app.py file
zip dictate-function.zip app.py


# upload new code to the lambda function
aws lambda update-function-code \
--function-name dictate-function \
--zip-file fileb://dictate-function.zip



# update the function handler using the command below 
aws lambda update-function-configuration \
--function-name dictate-function \
--handler app.lambda_handler




# invoke the lambda function
aws lambda invoke \
--function-name dictate-function \
--payload fileb://event.json response.txt
