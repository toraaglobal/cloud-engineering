#!/bin/bash

# create a variable for the ARN that the function will use
roleArn=$(aws iam list-roles --output text --query 'Roles[?contains(RoleName, `lambdaPollyRole`) == `true`].Arn')


# foldername
folderName=createUpdate-function
notesTable='Notes'

# change directory 
cd ~/environment/api/$folderName


# zip the app.py file 
zip $folderName.zip app.py


# create the lambda function
aws lambda create-function \
--function-name $folderName  \
--handler app.lambda_handler \
--runtime python3.9 \
--role $roleArn \
--environment Variables={TABLE_NAME=$notesTable} \
--zip-file fileb://$folderName.zip




## Test the function 
functionName=$folderName

aws lambda invoke \
--function-name $functionName \
--payload fileb://event.json response.txt